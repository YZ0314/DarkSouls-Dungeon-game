# designosouls
 Soul of Cinder (final boss)
Description: After the 2 Lord of Cinders are defeated, the player will have access to the fog door to the Kiln Of The First Flame. This will lead to a new map that is generated to defeat the final boss (Soul of Cinder). Soul of Cinder is holding FireLink GreatSword as its weapon. It is able to cast magic skill before the ember form activates.
Ember form: When the soul of cinder hitpoint reaches or is less than 0, the Hit points will be restored to its maximum and the soul of cinder will be able to use the active skill (EmberSkill). Once EmberSkill is activated, it will stun the player for 1 round, deal double damage to the player and burn ground at the same time. However, there will be a 3 round Cooldown for EmberSkill whenever the soul of cinder activates it.
Requirements
Features (HOW) / Your Approach / Your Answer
Must use at least two (2) classes from the engine package.
Action, Weapon Action - EmberSkill
GameMap - Kiln Of The FIrst Flame map
Actor - Soul of Cinder
WeaponItem - FireLink GreatSword
Must use/re-use at least one (1) existing feature (either from A2 and/or A3 - fixed requirements)
Bonfire - The new map for the final boss contains a new bonfire. If a user interacts with the bonfire, it will update the spawn position.
FogDoor - In order to enter the fog door to the final boss, the player is required to collect both corpses of Yhorm and Aldrich. The player also cannot leave the new map until the soul of Cinder is killed.
Must use existing or create new abstraction/interfaces (apart from the engine code).
Resettable, Behaviour - The final boss’ behaviour and position will be reset when the player dies.
LordOfCinder - The final boss extends to LordOfCinder (abstract class) as it is a boss
Must use existing or create new capabilities.
Abilities.ACTIVE_SKILL - to use active skill
Status.EMBER - used when Ember form is activated
Abilities.RESET - reset the soul of cinder
Status.COOLDOWN - count the cooldown for the active skill
Status.STUN - active skill able to stun player for 1 round
Status.DIRT - burn ground
Single Responsibility Principle - each class is responsible for a specific task (Eg. Ember,
Dependency inversion Principle - behaviour interface and resettable interface. Only has to be implemented once instead of each behaviour class one by one.
Open/Close Principle - Extension to LordOfCInder and Weapons are possible without having to modify existing code.











Magical system
Description: With enough souls, the player will be able to buy a special item called Spell Item (500 souls) from the Vendor, allowing the player to use Magic. Like the player’s Hit points (HP), there will be Magic points (MP) which limit the players to use magic. Similar to the Estus Flask, the Ashen Estus Flask will increase the number of MPs by 40%. The Magic miracle includes:
1) Replenishment (1000 souls): increases 10HP for 6 rounds, reduces 15MP per use.
   2)CarthusFlameArc(1000 souls): enhance the weapon currently holded, times 1.5 damage of current weapon for each attack, reduce 100 MP per use
   Requirements
   Features (HOW) / Your Approach / Your Answer
   Must use at least two (2) classes from the engine package.
   Item - Ashen Estus Flask, SpellItem, SpellMagic, ReplenishMagic, CarthusFlameArc
   Action - SpellAction
   Must use/re-use at least one (1) existing feature (either from A2 and/or A3 - fixed requirements)
   Vendor - Magic skills and SpellItem are available to be bought from Vendor. But Magic skills cannot be bought until player has the SpellItem
   PurchaseAction - When player has enough souls, player will be able to buy SpellItem, and then specific Magic
   ConsumeAction - When AshenEstusFlask is consumed, the number of MP will increase

    
Must use existing or create new abstraction/interfaces (apart from the engine code).
Purchasable - This will be used in all classes that can be purchased from vendor
Consumable - this will be used in all classes that can allow player to consume to improve hitpoints/magicpoints
Magic - This will be used in all classes that contains magic spells
Soul - exchange items with souls
SpellMagic - All magic spells will extend to this abstract class
Must use existing or create new capabilities.
Abilities.INCREASE_DAMAGE - used to increase damage when buff spell is used
Abilities.HEAL - used to heal actor when healing spell is used
Abilities.CAST_SPELL - when player has “SpellItem”, it is only then that the magic spells can be utilized
Must explain why it adheres to the SOLID principles.
Open/Close Principle - the AshenEstusFlask and the Magic spells are examples of open to extension and closed to modification.
Single Responsibility Principle - Each magic/AshenEstusFlask is responsible for their own tasks.
Dependency inversion Principle - used as all classes that are consumable are implemented to Consumable and ConsumeAction is only associated to consumable.With the use of consumable interface, methods can be implemented without adding associations in ConsumeAction class one by one.


