package game;

import edu.monash.fit2099.engine.*;

import java.util.Random;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A class for broad Sword that extend Melee Weapon
 */
public class BroadSword extends MeleeWeapon {
    protected Random random = new Random();
    protected Display display = new Display();

    /**
     * Constructor for Broad Sword
     */
    public BroadSword() {
        super("BroadSword",'s', 30, "hits", 80,500);
    }

    /**
     * method for calculate the damage for Weapon (maybe cause Critical Strike)
     * @return  the damage for the Weapon
     */
    @Override
    public int damage() {
        if ( random.nextInt(100) <= 20){
            display.println("Critical Strike!!!");
            return damage * 2;
        }
        return damage;
    }
}
