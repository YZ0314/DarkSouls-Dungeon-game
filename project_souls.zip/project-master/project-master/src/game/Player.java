package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;
import game.enums.Status;
import game.interfaces.Resettable;
import game.interfaces.Soul;

import java.util.ArrayList;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * Class representing the Player.
 */
public class Player extends Actor implements Soul, Resettable {
	protected ArrayList<Location> preLocation;
	private int soul;	// player soul
	private final Menu menu = new Menu();	// menu of action that player can choose
	private int magicPoint;
	private int maxMagicPoint;

	/**
	 * Constructor.
	 *
	 * @param name        Name to call the player in the UI
	 * @param displayChar Character to represent the player in the UI
	 * @param hitPoints   Player's starting number of hitpoints
	 */
	public Player(String name, char displayChar, int hitPoints) {
		super(name, displayChar, hitPoints);
		registerInstance();
		preLocation = new ArrayList<Location>();	// store the player location
		this.addItemToInventory(new BroadSword());
		this.addItemToInventory(new EstusFlask());
		this.addItemToInventory(new AshenEstusFlask());
		this.addCapability(Status.HOSTILE_TO_ENEMY);
		this.addCapability(Abilities.REST);
		this.addCapability(Status.PLAYER);
		this.addCapability(Abilities.TRADE);
		this.addCapability(Abilities.TOKEN);
		this.addCapability(Abilities.PICK);
		this.magicPoint = 100;
		this.maxMagicPoint = 100;
		this.soul = 100000;
	}

	/**
	 * get the max magic points
	 * @return the number of max magic points
	 */
	public int getMaxMagicPoint() {
		return maxMagicPoint;
	}

	/**
	 * increase the number of mp
	 * @param magicPoint the number of magic points player has
	 */
	public void restoreMP(int magicPoint){
		this.magicPoint += magicPoint;
		this.magicPoint = Math.min(this.magicPoint, this.maxMagicPoint);
	}

	/**
	 * get the magic point
	 * @return the number of magic points
	 */
	public int getMagicPoint() {
		return magicPoint;
	}

	/**
	 * decrease the number of mp
	 * @param magicPoint the number of magic points player has
	 */
	public void subtractMP(int magicPoint){
		this.magicPoint-=magicPoint;
		this.magicPoint=Math.max(this.magicPoint,0);
	}

	/**
	 * get player weapon
	 * @return	player current weapon
	 */
	@Override
	public Weapon getWeapon() {
		return super.getWeapon();
	}

	/**
	 * the action that player can do in his turn
	 */
	@Override
	public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
		// Handle multi-turn Actions
		if (lastAction.getNextAction() != null)
			return lastAction.getNextAction();

		// fall or is killed
		if (!isConscious()){
			ResetManager.getInstance().run();	// run reset Mange to reset everything
			Token token = new Token();
			map.moveActor(this, preLocation.get(preLocation.size() - 1));
			transferSouls(token.asSoul());
			addItemToInventory(token);
			DropItemAction dropItemAction = new DropItemAction(token);
			dropItemAction.execute(this,map);
			RespawnAction respawnAction = new RespawnAction(preLocation.get(0));
			display.println("____     ___    ____    ____     ___      ________   ______________ ________   \n" +
					"`MM(     )M'   6MMMMb   `MM'     `M'      `MMMMMMMb. `MM'`MMMMMMMMM `MMMMMMMb. \n" +
					" `MM.    d'   8P    Y8   MM       M        MM    `Mb  MM  MM      \\  MM    `Mb \n" +
					"  `MM.  d'   6M      Mb  MM       M        MM     MM  MM  MM         MM     MM \n" +
					"   `MM d'    MM      MM  MM       M        MM     MM  MM  MM    ,    MM     MM \n" +
					"    `MM'     MM      MM  MM       M        MM     MM  MM  MMMMMMM    MM     MM \n" +
					"     MM      MM      MM  MM       M        MM     MM  MM  MM    `    MM     MM \n" +
					"     MM      MM      MM  MM       M        MM     MM  MM  MM         MM     MM \n" +
					"     MM      YM      M9  YM       M        MM     MM  MM  MM         MM     MM \n" +
					"     MM       8b    d8    8b     d8        MM    .M9  MM  MM      /  MM    .M9 \n" +
					"    _MM_       YMMMM9      YMMMMM9        _MMMMMMM9' _MM__MMMMMMMMM _MMMMMMM9'");
			return respawnAction;
		}

		if(hasCapability(Status.STUN)){
			removeCapability(Status.STUN);
			display.println("Player got stun");
			return new DoNothingAction();
		}

		if(hasCapability(Status.LIGHTING)){
			removeCapability(Status.LIGHTING);
			preLocation.clear();
		}
		preLocation.add(map.locationOf(this));
		actions.add(getWeapon().getActiveSkill(this,""));		//active skill

		// return/print the console menu
		display.println(name + "(" + hitPoints + "/" + maxHitPoints + ")" + ", holding "+ getWeapon() + ", Soul:" + soul);
		display.println("Magic Point: "+"("+getMagicPoint()+"/"+getMaxMagicPoint()+")");

		if (hasCapability(Abilities.HEAL)){
			display.println("Heal: Replenish");
		}

		if(hasCapability(Abilities.INCREASE_DAMAGE)){
			display.println("Buff: CarthusFlameArc");
		}

		return menu.showMenu(this, actions, display);
	}

	/**
	 * get player hitpoint
	 * @return	player current hitpoint
	 */
	public int getHitPoints(){
		return hitPoints;
	}

	/**
	 * get player current soul
	 * @return player current soul
	 */
	public int getSoul() {
		return soul;
	}

	/**
	 * transfer player soul to another soulObject
	 */
	@Override
	public void transferSouls(Soul soulObject) {
		//TODO: transfer Player's souls to another Soul's instance.
		soulObject.addSouls(soul);
		soul = 0;
	}

	/**
	 * add player soul
	 * @return new player soul amount
	 */
	@Override
	public boolean addSouls(int souls) {
		soul += souls;
		return true;
	}

	/**
	 * reduce the player soul
	 */
	@Override
	public boolean subtractSouls(int souls) {
		if (getSoul() >= souls){
			this.soul = this.soul-souls;
			return true;
		}
		return false;
	}

 	/**
 	 * reset player and heal back it hp
 	 */
	@Override
	public void resetInstance() {
		this.addCapability(Abilities.RESET);
		hitPoints = maxHitPoints;
		magicPoint = maxMagicPoint;
		removeCapability(Status.FULL_CHARGE);
		removeCapability(Status.CHARGE);
		removeCapability(Abilities.HEAL);
		removeCapability(Abilities.INCREASE_DAMAGE);
	}

	/**
	 * set it permanent in resettable list
	 */
	@Override
	public boolean isExist() {
		return true;
	}
}
