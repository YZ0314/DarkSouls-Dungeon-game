package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Item;
import game.interfaces.Magic;
import game.interfaces.Purchasable;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * An abstract class for all magic spells that extend Item
 */
public abstract class SpellMagic extends Item implements Magic, Purchasable {
    int magic;
    int cost;

    /***
     * Constructor of Spell magic
     *  @param name the name of this Item
     * @param displayChar the character to use to represent this item if it is on the ground
     * @param portable true if and only if the Item can be picked up
     */
    public SpellMagic(String name, char displayChar, boolean portable, int cost, int magic) {
        super(name, displayChar, portable);
        this.cost = cost;
        this.magic = magic;
        allowableActions.add(new SpellAction(name,this));
    }

    /**
     * To get the number of MP needed to use spell
     * @return Magic point of magic spell
     */
    @Override
    public int getSpellMP() {
        return magic;
    }

    /**
     * The capability given to actor to activate the spell
     * @param actor the actor that uses the magic spell
     * @return message if spell is used
     */
    @Override
    public String spellBy(Actor actor) {
        return null;
    }

    /**
     * get the cost of the magic spells
     * @return  cost of the spell
     */
    @Override
    public int getCost() {
        return cost;
    }

    /**
     * The actor will be able to use Replenish Magic spell
     * @param actor the actor that buys the spell
     * @param map the map the actor is in
     * @return message displaying if item is bought
     */
    @Override
    public String getPurchase(Actor actor, GameMap map) {
        actor.addItemToInventory(this);
        return actor + " bought the " + name;
    }
}
