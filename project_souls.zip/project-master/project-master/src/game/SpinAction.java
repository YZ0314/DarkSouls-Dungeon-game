package game;

import edu.monash.fit2099.engine.*;
import game.enums.Status;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * An action for spin attack
 */
public class SpinAction extends WeaponAction{
    protected WeaponAction weaponAction;
    public SpinAction(WeaponItem weaponItem) {
        super(weaponItem);
    }

    /**
     * A method that activate spin attack
     * @param actor actor that use the skill
     * @param map  map that actor in
     * @return  statement if the user is killed or just print out spin attack is activated
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        Location here = map.locationOf(actor);
        String result = "";
        for (Exit exit : here.getExits()) {
            Location destination = exit.getDestination();   // get actor direction
            if (destination.containsAnActor()) {
                // player turn
                if (destination.getActor().hasCapability(Status.ENEMY) && actor.hasCapability(Status.PLAYER)){
                    int damage = actor.getWeapon().damage()/2;  // deal 25 damage
                    result += destination.getActor() + " ";
                    destination.getActor().hurt(damage);
                    if (!destination.getActor().isConscious()){
                        DyingAction dyingAction = new DyingAction(destination.getActor());
                        dyingAction.execute(actor,map);
                    }
                }
                // enemy turn
                if (destination.getActor().hasCapability(Status.PLAYER)){
                    int damage = actor.getWeapon().damage()/2;
                    result = destination.getActor() + " ";
                    destination.getActor().hurt(damage);
                }
            }
        }
        if (result != ""){
            return result + "get hits " + actor.getWeapon().damage()/2+ " damage by " + actor +"(Spain Attack)" ;
        }
        return actor + "activate Spin Attack";
    }

    /**
     * print out action in console
     * @param actor actor
     * @return player can activate spin attack in console
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Active Skill (Spin Attack__25 damage)";
    }
}
