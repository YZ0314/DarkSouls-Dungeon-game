package game;


import edu.monash.fit2099.engine.*;
import game.enums.Status;
import game.interfaces.Resettable;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * An undead minion.
 */
public class Undead extends Enemy implements Resettable {

	/** 
	 * Constructor.
	 * All Undeads are represented by an 'u' and have 30 hit points.
	 * @param name the name of this Undead
	 */
	public Undead(String name) {
		super(name, 'u', 50, 50);
		behaviours.add(0,new WanderBehaviour());
		registerInstance();
		this.addCapability(Status.WANDER);
	}

	/**
	 * Undead action play turn
	 * @see edu.monash.fit2099.engine.Actor#playTurn(Actions, Action, GameMap, Display)
	 */
	@Override
	public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
		// loop through all behaviours
		// remove undead from the map
		if (!isConscious()){
			return new RemoveActorAction();
		}
		return super.playTurn(actions,lastAction,map,display);
	}

	/**
	 * get the undead weapon
	 * @return	undead weapon
	 */
	@Override
	public Weapon getWeapon() {
		return new IntrinsicWeapon(20, "thwacks");
	}

	/**
	 * print the undead stats
	 * @return	undead stats
	 */
	@Override
	public String toString() {
		return name + "(" + hitPoints + "/" + maxHitPoints + ")";
	}

	/**
	 * reset the undead
	 */
	@Override
	public void resetInstance() {
		hurt(maxHitPoints);	//kill the undead
	}

	/**
	 * make it permanent in the resettable list
	 * @return	true
	 */
	@Override
	public boolean isExist() {
		return true;
	}
}
