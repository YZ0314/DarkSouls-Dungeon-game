package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.WeaponAction;
import game.enums.Status;

/**
 * The Soul of Cinder weapon
 */
public class FireLinkGreatSword extends MeleeWeapon{
    private int round = 0;
    /**
     * Constructor.
     **/
    public FireLinkGreatSword() {
        super("FireLink Great Sword", 'F', 150, "hit", 70, 0);
    }

    /**
     * able to active ember action skill
     * @param actor the actor holding weapon
     * @param direction the direction of target, e.g. "north"
     * @return
     */
    @Override
    public WeaponAction getActiveSkill(Actor actor, String direction) {
        return new EmberAction(this);
    }

    /**
     * if Soul of Cinder is ember form then hitrate will change and a counter for the Active Skill (Cool down)
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        if (actor.hasCapability(Status.EMBER)){
            hitRate = 90;
        }
        if (round < 2 && actor.hasCapability(Status.COOLDOWN)){
            round++;
        }
        if (round == 2){
            actor.removeCapability(Status.COOLDOWN);
            round = 0;
        }
    }
}
