package game.enums;

/**
 * Use this enum class to give `buff` or `debuff`.
 * It is also useful to give a `state` to abilities or actions that can be attached-detached.
 */
public enum Status {
    HOSTILE_TO_ENEMY, // use this capability to be hostile towards something (e.g., to be attacked by enemy)
    DIRT,   // use this capability to make sure the ground is dirt
    ENEMY,  // use this capability to determine it is an enemy
    CHARGE, // use this capability to determine player is charging Storm Ruler
    PLAYER, // use this capability to determine the actor is player
    FULL_CHARGE,    // use this capability to determine the storm ruler able to use wind slash
    STUN,   // use this capability to determine the actor is in stun
    SKILL_ATTACK,   // use this capability to determine weapon is using skill_attack (finding the damage)
    EMBER,   // use this capability to determine yhorm is in ember form
    COOLDOWN,   // use this capability to determine if actor is in cooldown stage
    ACTIVE_BONFIRE, // use this capability to determine if bonfire is activated
    LIGHTING,   // use this capability to determine if lightning is used
    WANDER  // use this capability to determine if actor can wander
}
