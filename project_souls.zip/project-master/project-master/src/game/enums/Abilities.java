package game.enums;

/**
 * Enum that represents an ability of Actor, Item, or Ground.
 */
public enum Abilities {
    TRADE,  // use this capability to determine actor have ability to trade
    RESET,  // use this capability to determine actor have ability to reset
    PICK,   // use this capability to determine actor have ability to pick up item
    TOKEN,  // use this capability to determine actor have ability drop or collect token
    REVIVE, // use this capability to determine actor have ability to revive
    DROP,   // use this capability to determine actor have ability to drop item
    ACTIVE_SKILL,   // use this capability to determine actor have ability to use active skill
    REST,    // use this capability to determine actor have ability to rest
    RANGE_ATTACK,   // use this capability to determine actor have ability to perform range attack
    CAST_SPELL, // use this capability to determine actor have ability to cast spell
    HEAL, // use this capability to determine actor have ability to heal
    INCREASE_DAMAGE // use this capability to determine item have ability to increase damage






}
