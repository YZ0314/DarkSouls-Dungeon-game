package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;
import game.interfaces.Soul;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * a class for token of soul
 */
public class Token extends Item implements Soul {

    /***
     * Constructor.
     * @param name the name of this Item
     * @param displayChar the character to use to represent this item if it is on the ground
     * @param portable true if and only if the Item can be picked up
     */
    private int soul;
    public Token() {
        super("Token of souls", '$', true);
        this.soul = 0;
    }

    /**
     * a pickup token action
     * @param actor an actor that will interact with this item
     * @return the pick up action
     */
    @Override
    public PickUpItemAction getPickUpAction(Actor actor) {
        PickUpItemAction pickUpItemAction = new PickUpItemAction(this);
        if (actor.hasCapability(Abilities.PICK)){
            actor.asSoul().addSouls(soul);      // pick up token if actor available
            this.addCapability(Abilities.PICK);
        }
        return pickUpItemAction;
    }

    /**
     * remove item from the map
     * @param currentLocation The location of the ground on which we lie.
     */
    @Override
    public void tick(Location currentLocation) {
        if (this.hasCapability(Abilities.PICK)) {
            currentLocation.removeItem(this);   // remove item from the map
        }
    }

    /**
     * do nothing
     * @param soulObject a target souls.
     */
    @Override
    public void transferSouls(Soul soulObject) {
    }

    /**
     * a map that add the actor soul to token
     * @param souls number of souls to be incremented.
     * @return true
     */
    @Override
    public boolean addSouls(int souls) {
        soul = souls;
        return true;
    }
}
