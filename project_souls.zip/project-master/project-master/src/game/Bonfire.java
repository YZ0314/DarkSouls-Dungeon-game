package game;

import edu.monash.fit2099.engine.*;
import game.enums.Status;
import java.util.HashMap;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * Set Ground to bonfire that allow player to rest
 */
public class Bonfire extends Ground {
    protected String bonfireName;   // name of the bonfire
    protected static HashMap<Location,Bonfire> bonfireLocation = new HashMap<>();  // save the location of the bonfire
    private Location actLocation;   // put the Location in to hashmap

    /**
     * Constructor of the bonfire
     * @param bonfireName
     */
    public Bonfire(String bonfireName) {
        super('B');
        this.bonfireName = bonfireName;
    }

    /**
     * allow actor to interact with bonfire
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return  action that actor can do
     */
    @Override
    public Actions allowableActions(Actor actor, Location location, String direction) {
        Actions actions = new Actions();
        if (this.hasCapability(Status.ACTIVE_BONFIRE)){ // check if it is active already
            actions.add(new RestAction(bonfireName));       // return restaction if yes
            for (Location key : bonfireLocation.keySet()){  // loop through the hashmap that allow player to teleport to there
                if (!(bonfireLocation.get(key).bonfireName == bonfireName)) {
                    actions.add(new TeleportAction(bonfireLocation.get(key), key));
                }
            }
            return actions;
        }
        if (!this.hasCapability(Status.ACTIVE_BONFIRE)){
            actions.add(new ActiveAction(this));    // return Active action if it is not active
        }
        return actions;
    }

    /**
     * Check if it is saved in actLocation then don't need to push to HashMap again
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        if (hasCapability(Status.ACTIVE_BONFIRE)){
            if(actLocation == null){
                this.actLocation = location;
                bonfireLocation.put(actLocation,this);
            }
        }
    }
}
