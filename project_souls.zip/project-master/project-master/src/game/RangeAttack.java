package game;

import edu.monash.fit2099.engine.*;
import game.enums.Status;
import game.interfaces.Behaviour;

import java.util.Random;

/**
 * Allow actor to shoot from far distance
 */
public class RangeAttack extends Action implements Behaviour {
    private Actor target;   // target
    protected Random rand = new Random();

    /**
     * Constructor
     * @param target
     */
    public RangeAttack(Actor target) {
        this.target = target;
    }

    /**
     * Check if there are targets with 3 square far away, if it contains actor then attack the target
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return  deal statement if there is nothing block, otherwise return statement to let actor know actor is blocked
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        Location here = map.locationOf(actor);
        Location there = map.locationOf(target);

        NumberRange xs, ys;
        if (here.x() == there.x() || here.y() == there.y()) {
            xs = new NumberRange(Math.min(here.x(), there.x()), Math.abs(here.x() - there.x()) + 1);
            ys = new NumberRange(Math.min(here.y(), there.y()), Math.abs(here.y() - there.y()) + 1);

            for (int x : xs) {
                for (int y : ys) {
                    if(map.at(x, y).getGround().blocksThrownObjects()) {
                        return actor + "'s attack is blocked";
                    }
                }
            }
            AttackAction attackAction = new AttackAction(target);
            if(actor.hasCapability(Status.EMBER)){
                map.locationOf(target).setGround(new BurnGround());
            }
            return attackAction.execute(actor,map);
        }
        return "";
    }

    /**
     * not in use
     * @param actor The actor performing the action.
     * @return null
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }

    /**
     * Range Attack behaviour for the enemy
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return  RangeAttack Action if there is player
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Location here = map.locationOf(actor);
        Location there = map.locationOf(target);
        int x = Math.abs(here.x() - there.x());
        int y = Math.abs(here.y() - there.y());
        if (here.x() == there.x() || here.y() == there.y()) {
            if (x <= 3 && y <= 3) {
                return new RangeAttack(target);
            }
        }
        return null;
    }
}
