package game.interfaces;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;

public interface Purchasable {
    /**
     * To get the cost (soul) of items from vendor
     * @return the number of souls in each item available in vendor
     */
    int getCost();

    /**
     * The process of preparing purchasing items
     * @param actor the actor that is purchasing items
     * @return purchase action performed by actor
     */
    String getPurchase(Actor actor, GameMap map);
}
