package game.interfaces;

import edu.monash.fit2099.engine.Actor;

public interface Magic {
    /**
     * To get the MP of spell magic objects
     * @return the number of MP in spell magic object
     */
    int getSpellMP();

    /**
     * The process of activating magic spell
     * @param actor the actor that is interacting with the spell
     * @return spell action performed by actor
     */
    String spellBy(Actor actor);
}
