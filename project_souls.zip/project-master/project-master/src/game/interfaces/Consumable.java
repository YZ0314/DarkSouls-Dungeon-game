package game.interfaces;

import edu.monash.fit2099.engine.Actor;

public interface Consumable  {
    /**
     * The process of consuming item
     * @param actor the actor that is consuming items
     * @return consume action performed by actor
     */
    String consumedBy(Actor actor);

    /**
     * The full name of item being consumed
     * @return display the name of item consumed
     */
    String getConsumeName();

    /**
     * Allows upcasting for Item to a Consumable instance if possible.
     * @return a reference to the current Item that can be consumed,
     *         or null if this Item doesn't implement it.
     */
    default Consumable asConsumable(){
        return this instanceof Consumable ? (Consumable) this : null;
    }
}



