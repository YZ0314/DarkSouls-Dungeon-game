package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A revive action if actor has ability to revie
 */
public class ReviveAction extends Action {
    private Location location;
    private Actor respawnActor; // actor who revive

    /**
     * constructor
     * @param location get the actor location
     * @param respawnActor   actor that revive
     */
    public ReviveAction(Location location, Actor respawnActor) {
        this.location = location;
        this.respawnActor = respawnActor;
    }

    /**
     * revive skeleton or create a reviving skeleton in a given position
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return  revive skeleton if it finished revive
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (actor.hasCapability(Abilities.REVIVE)){
            map.removeActor(actor);
            map.addActor(respawnActor,location);
            return "Skeleton has revived";
        }
        map.removeActor(actor);
        map.addActor(new ReviveSkeleton(respawnActor),location);
        return ("Skeleton will revive in next turn");
    }

    /**
     * do nothing
     * @param actor The actor performing the action.
     * @return null
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
