package game;

import game.enums.Abilities;
import game.enums.Status;
import game.interfaces.Resettable;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * The boss of Design o' Souls
 */
public abstract class LordOfCinder extends Enemy implements Resettable {
    /**
     * Constructor.
     */
    public LordOfCinder(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints, 5000);
        this.addCapability(Abilities.DROP);
        registerInstance();
    }

    /**
     * run the code if the reset is start
     */
    @Override
    public void resetInstance() {
        behaviours.clear();
        addCapability(Abilities.RESET);
        removeCapability(Status.EMBER);
    }

    /**
     * permanent for actor to store in resettable list
     * @return true
     */
    @Override
    public boolean isExist() {
        return true;
    }
}
