package game;

import java.util.Arrays;
import java.util.List;

import edu.monash.fit2099.engine.*;

/**
 * The main class for the Jurassic World game.
 *
 */

/*
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

public class Application {

	public static void main(String[] args) {

			World world = new World(new Display());

			FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(), new Wall(), new Floor(), new Valley(), new Cemetery());

			List<String> map1 = Arrays.asList(
					"..++++++..+++...........................++++......+++.................+++.......",
					"........+++++..............................+++++++.................+++++........",
					"...........+++.......................................................+++++......",
					"........................................................................++......",
					".........................................................................+++....",
					"............................+.............................................+++...",
					".............................+++.......++++.....................................",
					".............................++.......+......................++++...............",
					".............................................................+++++++............",
					"..................................###___###...................+++...............",
					"..................................#_______#......................+++............",
					"...........++.....................#_______#.......................+.............",
					".........+++......................#_______#........................++...........",
					"............+++...................####_####..........................+..........",
					"..............+......................................................++.........",
					"..............++.................................................++++++.........",
					"............+++...................................................++++..........",
					"+..................................................................++...........",
					"++...+++.........................................................++++...........",
					"+++......................................+++........................+.++........",
					"++++.......++++.........................++.........................+....++......",
					"#####___#####++++......................+...............................+..+.....",
					"_..._....._._#.++......................+...................................+....",
					"...+.__..+...#+++...........................................................+...",
					"...+.....+._.#.+.....+++++...++..............................................++.",
					"___.......___#.++++++++++++++.+++.............................................++");
			GameMap profaneCapital = new GameMap(groundFactory, map1);
			world.addGameMap(profaneCapital);

			List<String> map2 = Arrays.asList(
					"................................#___________#...........................++++....",
					"................................#___________#.......................++++++......",
					"....+++++..+....................#####___#####.....................+++...........",
					".......+++......................................................................",
					"......+++.......................................................................",
					"..++.+................................................+.++......................",
					"++.............................++......................++.......................",
					"+.....................+.........++++....+++.............+.......................",
					"....................+.++#############___##################......................",
					".......................+#...#..............+...._........#......................",
					"........................#........__.................#....#................++....",
					"........................#._......#............+#.........#++.................+..",
					"........................#..__........................__..#+.+...............+...",
					".............++++.......#........#+............#......._.#++.................++.",
					"...............++.+.....#....#.................__........#......................",
					".............+++........#........_....+..............#...#......................",
					"............+++........+####################___###########......................",
					"............++.++.......+...............++.+...++++.............................",
					".......................................+........++..............................",
					".+........................................................................++....",
					"++++...................................................................++.+.....");
			GameMap anorLondo = new GameMap(groundFactory, map2);
			world.addGameMap(anorLondo);

			List<String> map3 = Arrays.asList(
					"..++...+++..+.+...............................................+.....++.+.+++.+..",
					"..++++................#################___################......................",
					".+++...............####.........#...........___..........####........++..++.....",
					".................####..............__...........##_........####.........+++.....",
					"...............###.......#...........#.....#..................###........+.+.++.",
					"#######.......##......._....+.......................+......__...##...+...++.....",
					"______#.......#+.............................+....................#.......+++..+",
					"_______.......#.....#............#.............#_...........#.....#.........++..",
					"______#.......#....__.............................................#..........+..",
					"#######++.....##..+......##.........+..............+............##..+...........",
					"......++.......###.................._#..+..#............__....###...............",
					"......+..........####....._......................#.........####.................",
					"...................####......+.......__.............__...####...................",
					"......................#################___################...............++.+...",
					"......++++..++....................................................++++.......+++");
			GameMap kilnOfTheFirstFlame = new GameMap(groundFactory, map3);
			world.addGameMap(kilnOfTheFirstFlame);

			// Place Player in Profane Capital
			Actor player = new Player("Unkindled (Player)", '@', 10000);
			world.addPlayer(player, profaneCapital.at(38,12));

			// Place Fog Door to Anor Londo in Profane Capital
			FogDoor fogDoor1 = new FogDoor(anorLondo.at(38, 0), "to Anor Londo");
			fogDoor1.allowableActions(player, anorLondo.at(38, 0), "to Anor Londo");
			profaneCapital.at(38, 25).setGround(fogDoor1);

			// Place Yhorm the Giant/boss in Profane Capital
			LordOfCinder yhorm = new YhormTheGiant(profaneCapital.at(6,25));
			profaneCapital.at(6, 25).addActor(yhorm);

			// Place Skeletons in Profane Capital
			profaneCapital.at(75, 3).addActor(new Skeleton("Skeleton",profaneCapital.at(75,3)));
			profaneCapital.at(21, 4).addActor(new Skeleton("Skeleton",profaneCapital.at(21,4)));
			profaneCapital.at(60, 5).addActor(new Skeleton("Skeleton",profaneCapital.at(60,5)));
			profaneCapital.at(45, 24).addActor(new Skeleton("Skeleton",profaneCapital.at(45,24)));

			// FIXME: the Undead should be generated from the Cemetery
			// Place cemeteries in Profane Capital
			profaneCapital.at(64, 5).setGround(new Cemetery());
			profaneCapital.at(3, 8).setGround(new Cemetery());
			profaneCapital.at(51, 12).setGround(new Cemetery());
			profaneCapital.at(26, 19).setGround(new Cemetery());
			profaneCapital.at(60, 23).setGround(new Cemetery());

			// Place Vendor in Profane Capital
			profaneCapital.at(36,10).addActor(new Vendor());

			// Place Bonfire in Profane Capital
			Bonfire bonfire1=new Bonfire("Firelink Shrine's Bonfire");
			profaneCapital.at(38,11).setGround(bonfire1);

			// Place Storm Ruler in Profane Capital
			profaneCapital.at(7,25).addItem(new StormRuler());

			// Place Fog Door to Profane Capital in Anor Londo
			FogDoor fogDoor2 = new FogDoor(profaneCapital.at(38, 25), "to Profane Capital");
			fogDoor2.allowableActions(player, profaneCapital.at(38, 25), "to Profane Capital");
			anorLondo.at(38, 0).setGround(fogDoor2);

			// Place Aldrich the Devourer/boss in Anor Londo
			AldrichTheDevourer aldrichTheDevourer = new AldrichTheDevourer(anorLondo.at(40,12));
			anorLondo.at(40, 12).addActor(aldrichTheDevourer);

			// Place Skeletons in Anor Londo2
			anorLondo.at(8, 1).addActor(new Skeleton("Skeleton",anorLondo.at(8, 1)));
			anorLondo.at(57, 3).addActor(new Skeleton("Skeleton",anorLondo.at(57, 3)));
			anorLondo.at(21, 5).addActor(new Skeleton("Skeleton",anorLondo.at(21, 5)));
			anorLondo.at(36, 19).addActor(new Skeleton("Skeleton",anorLondo.at(36, 19)));

			// FIXME: the Undead should be generated from the Cemetery
			// Place cemeteries in Anor Londo
			anorLondo.at(13, 4).setGround(new Cemetery());
			anorLondo.at(65, 6).setGround(new Cemetery());
			anorLondo.at(8, 10).setGround(new Cemetery());
			anorLondo.at(70, 15).setGround(new Cemetery());
			anorLondo.at(30, 17).setGround(new Cemetery());

			// Place Bonfire in Anor Londo
			Bonfire bonfire2 = new Bonfire("Anor Londo's Bonfire");
			anorLondo.at(38,1).setGround(bonfire2);

			// Place Fog Door to Kiln Of The First Flame in Profane Capital if both bosses killed
			FogDoor fogDoor3 = new FogDoor(kilnOfTheFirstFlame.at(0,6), "to Kiln Of The First Flame");
			profaneCapital.at(35,10).setGround(fogDoor3);
			fogDoor3.allowableActions(player, kilnOfTheFirstFlame.at(0,6), "to Kiln Of The First Flame");


			// Place Fog Door to Profane Capital in Kiln Of The First Flame if final boss killed
			FogDoor fogDoor4 = new FogDoor(profaneCapital.at(35, 10), "to Profane Capital");
			fogDoor4.allowableActions(player, profaneCapital.at(35, 10), "to Profane Capital");
			kilnOfTheFirstFlame.at(0, 6).setGround(fogDoor4);

			// Place Bonfire in Anor Londo
			Bonfire bonfire3 = new Bonfire("Kiln Of The First Flame Bonfire");
			kilnOfTheFirstFlame.at(2,7).setGround(bonfire3);

			// Place Soul of Cinder/boss in Kiln Of The First Flame
			kilnOfTheFirstFlame.at(40, 7).addActor(new SoulOfCinder("Soul of Cinder",'S',1, kilnOfTheFirstFlame.at(40,7)));
			world.run();
	}
}
