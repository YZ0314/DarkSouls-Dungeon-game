package game;

import java.util.Random;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;
import game.enums.Status;
import game.interfaces.Behaviour;

/**
*	@author: KAM LUNG YIM
* 	@author: Trinna De Guzman
* 	@author: Ivan He
*
*	@Version: 1.0.0
* 	@last updated: 26/09/2021
 */

/**
 * Special Action for attacking other Actors.
 */
public class AttackAction extends Action implements Behaviour {

	/**
	 * The Actor that is to be attacked
	 */
	protected Actor target;

	/**
	 * The direction of incoming attack.
	 */
	protected String direction;

	/**
	 * Random number generator
	 */
	protected Random rand = new Random();

	/**
	 * Constructor.
	 * @param direction attack direction
	 * @param target the Actor to attack
	 */
	public AttackAction(Actor target, String direction) {
		this.target = target;
		this.direction = direction;
	}

	/**
	 * Constructor.
	 * @param target
	 */
	public AttackAction(Actor target) {
		this.target = target;
	}

	/**
	 * Method is an attack action for actor to it target. It also determines whether the attack is hit the target.
	 * @param actor The actor performing the action.
	 * @param map The map the actor is on.
	 * @return	string statement which print out how much damage do the actor did to target or whether it is killed or
	 * attack is missed
	 */
	@Override
	public String execute(Actor actor, GameMap map) {

		Weapon weapon = actor.getWeapon();

		if (!(rand.nextInt(100) <= weapon.chanceToHit())) {
			return actor + " misses " + target + ".";
		}

		int damage = weapon.damage();
		if(actor.hasCapability(Abilities.INCREASE_DAMAGE)){damage*=1.5;}
		String result = actor + " " + weapon.verb() + " " + target + " for " + damage + " damage.";
		target.hurt(damage);
		if (actor instanceof SoulOfCinder && actor.hasCapability(Status.EMBER)){
			map.locationOf(target).setGround(new BurnGround());
		}
		if (!target.isConscious()){
			DyingAction dyingAction = new DyingAction(target);
			dyingAction.execute(actor,map);
			return result + "\n" + target + " is killed";
		}
		return result;
	}

	/**
	 * method for the NPC behaviour to attack the player or use the skill ability
	 * @param actor the Actor acting
	 * @param map the GameMap containing the Actor
	 * @return	action for the NPC, it can be skill ability or normal attack
	 */
	@Override
	public Action getAction(Actor actor, GameMap map) {
		Location here = map.locationOf(actor);
		Location there = map.locationOf(target);

		for (Exit exit : here.getExits()) {
			Location destination = exit.getDestination();

			if (destination.containsAnActor() && destination.getActor().hasCapability(Status.HOSTILE_TO_ENEMY)) {
				if (actor.hasCapability(Abilities.ACTIVE_SKILL) && !actor.hasCapability(Status.COOLDOWN)){
					if ((rand.nextInt(100) <= 50)){
						return actor.getWeapon().getActiveSkill(actor,"");
					}
				}
				// allow actor to cast spell
				if (actor.hasCapability(Abilities.CAST_SPELL) && !actor.hasCapability(Status.EMBER)){
					if ((rand.nextInt(100) <= 25)){
						return new LightningStake(target);
					}
				}
				return new AttackAction(target,direction);
			}
		}
		return null;
	}

	/**
	 * method to print out the attack action perform
	 * @param actor The actor performing the action.
	 * @return	attack action perform
	 */
	@Override
	public String menuDescription(Actor actor) {
		return actor + " attacks " + target + " at " + direction;
	}
}
