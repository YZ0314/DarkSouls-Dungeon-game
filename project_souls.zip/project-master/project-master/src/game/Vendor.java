package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A vendor class for Fire Keeper
 */
public class Vendor extends Actor{
    Action action;  // vendor action

    /**
     * Constructor
     */
    public Vendor() {
        super("Fire Keeper", 'F', (int) Double.POSITIVE_INFINITY);
    }

    /**
     * always do nothing
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        return new DoNothingAction();
    }

    /**
     * player can buy weapon from the vendor
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return  the buying action
     */
    @Override
    public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {
        Actions actions = new Actions();
        actions.add(new PurchaseAction(new BroadSword()));
        actions.add(new PurchaseAction(new GiantAxe()));
        actions.add(new PurchaseAction(new SpellItem()));
        if (otherActor.hasCapability(Abilities.CAST_SPELL)){
            actions.add(new PurchaseAction(new CarthusFlameArc()));
            actions.add(new PurchaseAction(new ReplenishMagic(otherActor)));
        }
        return actions;
    }
}