package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;
import game.enums.Abilities;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * An action to respawn actor back to initial location
 **/
public class RespawnAction extends Action {
    protected Location location;

    /**
     * constructor
     * @param location  initial location
     */
    public RespawnAction(Location location) {
        this.location = location;
    }

    /**
     * spawn the player back to it initial location
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return  player has respawned
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        map.moveActor(actor, location);
        actor.removeCapability(Abilities.RESET);
        if (actor.hasCapability(Abilities.TOKEN)) {
            return "Player Has Respawn";
        }
        return "";
    }

    /**
     * print null
     * @param actor The actor performing the action.
     * @return nothing
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
