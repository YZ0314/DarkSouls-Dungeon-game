package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A Replenish Magic class for a Spell magic
 */
public class ReplenishMagic extends SpellMagic {
    private Actor actor;
    private int current;
    private Display display = new Display();

    /**
     * Constructor for Replenish magic class
     */
    public ReplenishMagic(Actor actor){
        super("Replenish Magic",'r',false, 1000,15);
        this.actor = actor;
        current = 0;
    }

    /**
     * The capability given to actor to activate the spell
     * @param actor the actor that uses the Replenish magic spell
     * @return message if spell is used
     */
    @Override
    public String spellBy(Actor actor) {
        actor.addCapability(Abilities.HEAL);
        return "Replenish health for 6 rounds!";
    }

    /**
     * The process of heal capability of Replenish magic
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        if (actor.hasCapability(Abilities.HEAL)) {
            current++;
            actor.heal(10);
            display.println("Heal: " + toString());
            if (current >= 6) {
                actor.removeCapability(Abilities.HEAL);
                display.println("Heal: End of Replenishment");
                current = 0;
            }
        }
    }

    /**
     * Display the current number of replenish magic
     * @return the magic name and number of current
     */
    @Override
    public String toString() {
        return  name + " (" + current + "/6)";
    }
}
