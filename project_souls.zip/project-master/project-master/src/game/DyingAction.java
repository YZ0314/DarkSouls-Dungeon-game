package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * dying action that see whether the actor is dead
 */
public class DyingAction extends Action {
    private Actor target;

    /**
     * constructor
     * @param target  actor that able to transfer soul or is killed
     */
    public DyingAction(Actor target) {
        this.target = target;
    }

    /**
     * Check whether the target is die if yes drop the item and transfer its soul and print is killed
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return  statement the target is killed
     */
    public String execute(Actor actor, GameMap map) {
        // drop all the item if target is dead (yhorm only)
        if (target.hasCapability(Abilities.DROP)) {
            Actions dropActions = new Actions();
            for (Item item : target.getInventory())
                dropActions.add(item.getDropAction(target));
            for (Action drop : dropActions)
                drop.execute(target, map);
        }

        if (actor.hasCapability(Abilities.TOKEN) && (!target.hasCapability(Abilities.REVIVE))) {
            // transfer current target soul to the actor if possible.
            target.asSoul().transferSouls(actor.asSoul());
        }
        return target + " is killed";
    }

    /**
     * print in the console
     * @return  print in the console
     */
    @Override
    public String toString() {
        return target + " ";
    }

    /**
     * nothing is use
     * @param actor The actor performing the action.
     * @return  nothing
     */
    public String menuDescription(Actor actor) {
        return null;
    }

}
