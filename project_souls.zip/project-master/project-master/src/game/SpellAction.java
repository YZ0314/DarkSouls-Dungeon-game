package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.interfaces.Magic;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * An SpellAction class for all magic spells that extend Action
 */
public class SpellAction extends Action {
    private Magic magic;
    private String spellMagicName;

    /**
     * A constructor for spell action
     */
    public SpellAction(String spellItemName, Magic magic){
        this.spellMagicName = spellItemName;
        this.magic = magic;
    }

    /**
     * To determine whether the actor able to perform magic if yes reduce the MP
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return  a statement that print whether the Mp is not enough
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if(((Player) actor).getMagicPoint()>=magic.getSpellMP()) {
            ((Player) actor).subtractMP(magic.getSpellMP());
            return magic.spellBy(actor);
        }
        return "Not enough Magic Points";
    }

    /**
     * print the action that enable the actor to perform magic in the menu
     * @param actor The actor performing the action.
     * @return  return magic action in the menu
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Use "+ spellMagicName;
    }
}
