package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;
import game.enums.Status;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * Class for yhorm
 */
public class YhormTheGiant extends LordOfCinder {
    private Location initial;   // inital location

    /**
     * Constructor
     * @param initial location
     */
    public YhormTheGiant(Location initial){
        super("Yhorm the Giant", 'Y', 500);
        addItemToInventory(new YhormGreatMachete());
        this.addItemToInventory(new CinderOfTheLord("Yhorm The Giant (Cinder of Lord)",this));
        this.initial = initial;
    }

    /**
     * getter for getting yhorm weapon
     * @return  yhorm current weapon
     */
    @Override
    public Weapon getWeapon() {
        return new YhormGreatMachete();
    }

    /**
     * action for yhorm can do in this turn
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return DoNothingAction
     * */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        if (!isConscious()){
            return new RemoveActorAction();
        }
        if (hasCapability(Abilities.RESET)){
            RespawnAction respawnAction = new RespawnAction(initial);   // respawn to initial location
            hitPoints = maxHitPoints;
            return respawnAction;
        }

        // active ember form
        if (hitPoints <= maxHitPoints/2 && !hasCapability(Status.EMBER)){
            this.addCapability(Abilities.ACTIVE_SKILL);
            this.addCapability(Status.EMBER);
            display.println("__________ ___       ___________   __________ ________          ________    ____    ________    ___       ___\n" +
                    "`MMMMMMMMM `MMb     dMM'`MMMMMMMb. `MMMMMMMMM `MMMMMMMb.        `MMMMMMM   6MMMMb   `MMMMMMMb.  `MMb     dMM'\n" +
                    " MM      \\  MMM.   ,PMM  MM    `Mb  MM      \\  MM    `Mb         MM    \\  8P    Y8   MM    `Mb   MMM.   ,PMM \n" +
                    " MM         M`Mb   d'MM  MM     MM  MM         MM     MM         MM      6M      Mb  MM     MM   M`Mb   d'MM \n" +
                    " MM    ,    M YM. ,P MM  MM    .M9  MM    ,    MM     MM         MM   ,  MM      MM  MM     MM   M YM. ,P MM \n" +
                    " MMMMMMM    M `Mb d' MM  MMMMMMM(   MMMMMMM    MM    .M9         MMMMMM  MM      MM  MM    .M9   M `Mb d' MM \n" +
                    " MM    `    M  YM.P  MM  MM    `Mb  MM    `    MMMMMMM9'         MM   `  MM      MM  MMMMMMM9'   M  YM.P  MM \n" +
                    " MM         M  `Mb'  MM  MM     MM  MM         MM  \\M\\           MM      MM      MM  MM  \\M\\     M  `Mb'  MM \n" +
                    " MM         M   YP   MM  MM     MM  MM         MM   \\M\\          MM      YM      M9  MM   \\M\\    M   YP   MM \n" +
                    " MM      /  M   `'   MM  MM    .M9  MM      /  MM    \\M\\         MM       8b    d8   MM    \\M\\   M   `'   MM \n" +
                    "_MMMMMMMMM _M_      _MM__MMMMMMM9' _MMMMMMMMM _MM_    \\M\\_      _MM_       YMMMM9   _MM_    \\M\\__M_      _MM_\n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "       _         ____   __________ ________     ___        _      __________ __________ ________             \n" +
                    "      dM.       6MMMMb/ MMMMMMMMMM `MM'`Mb(     )d'       dM.     MMMMMMMMMM `MMMMMMMMM `MMMMMMMb.           \n" +
                    "     ,MMb      8P    YM /   MM   \\  MM  YM.     ,P       ,MMb     /   MM   \\  MM      \\  MM    `Mb           \n" +
                    "     d'YM.    6M      Y     MM      MM  `Mb     d'       d'YM.        MM      MM         MM     MM           \n" +
                    "    ,P `Mb    MM            MM      MM   YM.   ,P       ,P `Mb        MM      MM    ,    MM     MM           \n" +
                    "    d'  YM.   MM            MM      MM   `Mb   d'       d'  YM.       MM      MMMMMMM    MM     MM           \n" +
                    "   ,P   `Mb   MM            MM      MM    YM. ,P       ,P   `Mb       MM      MM    `    MM     MM           \n" +
                    "   d'    YM.  MM            MM      MM    `Mb d'       d'    YM.      MM      MM         MM     MM           \n" +
                    "  ,MMMMMMMMb  YM      6     MM      MM     YM,P       ,MMMMMMMMb      MM      MM         MM     MM           \n" +
                    "  d'      YM.  8b    d9     MM      MM     `MM'       d'      YM.     MM      MM      /  MM    .M9           \n" +
                    "_dM_     _dMM_  YMMMM9     _MM_    _MM_     YP      _dM_     _dMM_   _MM_    _MMMMMMMMM _MMMMMMM9'           \n" +
                    "                                                                                                  ");
        }
        return super.playTurn(actions, lastAction, map, display);
    }
}
