package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.WeaponAction;
import edu.monash.fit2099.engine.WeaponItem;
import game.enums.Status;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * Create a charge action for actor to charge the weapon
 */
public class ChargeAction extends WeaponAction {
    /**
     * constructor for the charge with its weapon
     * @param weaponItem    Storm Ruler
     */
    public ChargeAction(WeaponItem weaponItem) {
        super(weaponItem);
    }

    /**
     * add the Capability status to actor when charging weapon
     * @param actor actor that use the charge
     * @param map   the map that where actor in
     * @return  String statement that let player they are start charging weapon
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        actor.addCapability(Status.CHARGE);
        return actor + "is start Charging Storm Rulur";
    }

    /**
     * print charging action for player
     * @param actor
     * @return  charge action in menu
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Charge Action (Active Skill)";
    }
}
