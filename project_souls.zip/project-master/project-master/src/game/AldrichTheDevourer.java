package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;
import game.enums.Status;

/**
 * Class that extend LordOfCinder
 */
public class AldrichTheDevourer extends LordOfCinder {
    private Location initial;   // initial location
    /**
     * Constructor for AldrichTheDevourer
     */
    public AldrichTheDevourer(Location initial) {

        super("Aldrich The Devourer", 'A', 350);
        this.addItemToInventory(new DarkmoonLongbow());
        this.addItemToInventory(new CinderOfTheLord("Aldrich The Devourer(Cinder Of The Lord)",this));
        this.initial = initial;
        this.addCapability(Abilities.RANGE_ATTACK);
    }

    /**
     * the action that actor can do in every round
     * @param actions actions performed by actor
     * @param lastAction the previous action perofrmed by actor
     * @param map map the actor is in
     * @param display displayed what action has been done
     * @return action performed by actor
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        if (!isConscious()){
            return new RemoveActorAction();
        }

        if (hasCapability(Abilities.RESET)){
            hitPoints = maxHitPoints;
            RespawnAction respawnAction = new RespawnAction(initial);   // respawn to initial location
            return respawnAction;
        }
        if ((hitPoints < maxHitPoints/2) && !hasCapability(Status.EMBER)){
            addCapability(Status.EMBER);
            display.println("__________ ___       ___________   __________ ________          ________    ____    ________    ___       ___\n" +
                    "`MMMMMMMMM `MMb     dMM'`MMMMMMMb. `MMMMMMMMM `MMMMMMMb.        `MMMMMMM   6MMMMb   `MMMMMMMb.  `MMb     dMM'\n" +
                    " MM      \\  MMM.   ,PMM  MM    `Mb  MM      \\  MM    `Mb         MM    \\  8P    Y8   MM    `Mb   MMM.   ,PMM \n" +
                    " MM         M`Mb   d'MM  MM     MM  MM         MM     MM         MM      6M      Mb  MM     MM   M`Mb   d'MM \n" +
                    " MM    ,    M YM. ,P MM  MM    .M9  MM    ,    MM     MM         MM   ,  MM      MM  MM     MM   M YM. ,P MM \n" +
                    " MMMMMMM    M `Mb d' MM  MMMMMMM(   MMMMMMM    MM    .M9         MMMMMM  MM      MM  MM    .M9   M `Mb d' MM \n" +
                    " MM    `    M  YM.P  MM  MM    `Mb  MM    `    MMMMMMM9'         MM   `  MM      MM  MMMMMMM9'   M  YM.P  MM \n" +
                    " MM         M  `Mb'  MM  MM     MM  MM         MM  \\M\\           MM      MM      MM  MM  \\M\\     M  `Mb'  MM \n" +
                    " MM         M   YP   MM  MM     MM  MM         MM   \\M\\          MM      YM      M9  MM   \\M\\    M   YP   MM \n" +
                    " MM      /  M   `'   MM  MM    .M9  MM      /  MM    \\M\\         MM       8b    d8   MM    \\M\\   M   `'   MM \n" +
                    "_MMMMMMMMM _M_      _MM__MMMMMMM9' _MMMMMMMMM _MM_    \\M\\_      _MM_       YMMMM9   _MM_    \\M\\__M_      _MM_\n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "       _         ____   __________ ________     ___        _      __________ __________ ________             \n" +
                    "      dM.       6MMMMb/ MMMMMMMMMM `MM'`Mb(     )d'       dM.     MMMMMMMMMM `MMMMMMMMM `MMMMMMMb.           \n" +
                    "     ,MMb      8P    YM /   MM   \\  MM  YM.     ,P       ,MMb     /   MM   \\  MM      \\  MM    `Mb           \n" +
                    "     d'YM.    6M      Y     MM      MM  `Mb     d'       d'YM.        MM      MM         MM     MM           \n" +
                    "    ,P `Mb    MM            MM      MM   YM.   ,P       ,P `Mb        MM      MM    ,    MM     MM           \n" +
                    "    d'  YM.   MM            MM      MM   `Mb   d'       d'  YM.       MM      MMMMMMM    MM     MM           \n" +
                    "   ,P   `Mb   MM            MM      MM    YM. ,P       ,P   `Mb       MM      MM    `    MM     MM           \n" +
                    "   d'    YM.  MM            MM      MM    `Mb d'       d'    YM.      MM      MM         MM     MM           \n" +
                    "  ,MMMMMMMMb  YM      6     MM      MM     YM,P       ,MMMMMMMMb      MM      MM         MM     MM           \n" +
                    "  d'      YM.  8b    d9     MM      MM     `MM'       d'      YM.     MM      MM      /  MM    .M9           \n" +
                    "_dM_     _dMM_  YMMMM9     _MM_    _MM_     YP      _dM_     _dMM_   _MM_    _MMMMMMMMM _MMMMMMM9'           \n" +
                    "                                                                                                  ");
            double currentHitpoint = hitPoints*0.2;    //calculate the current hitpoint * 0.2
            heal((int) currentHitpoint);   // heal it back
        }
        return super.playTurn(actions, lastAction, map, display);
    }

    /**
     * actions that actor can to do other actor
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return  Actions
     */
    @Override
    public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {
        return super.getAllowableActions(otherActor,direction,map);
    }
}
