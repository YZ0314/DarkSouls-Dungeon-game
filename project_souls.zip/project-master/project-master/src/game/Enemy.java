package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;
import game.enums.Status;
import game.interfaces.Behaviour;
import game.interfaces.Soul;

import java.util.ArrayList;

/**
 * Class for Enemy
 */
public abstract class Enemy extends Actor implements Soul {
    protected ArrayList<Behaviour> behaviours = new ArrayList<Behaviour>();
    private int soul; // enemy soul

    private Behaviour followBehaviour;

    /**
     * constructor for enemy
     * @param name
     * @param displayChar
     * @param hitPoints
     * @param soul
     */
    public Enemy(String name, char displayChar, int hitPoints, int soul) {
        super(name, displayChar, hitPoints);
        this.soul = soul;
        this.addCapability(Status.ENEMY);
    }

    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        if(this.hasCapability(Status.STUN)){
            display.println(this.name + " is stun for 1 round");
            removeCapability(Status.STUN);
            return new DoNothingAction();
        }

        for(game.interfaces.Behaviour Behaviour : behaviours) {
            Action action = Behaviour.getAction(this, map); // enemy behaviour
            if (action != null)
                return action;
        }
        return new DoNothingAction();
    }

    /**
     * At the moment, we only make it can be attacked by enemy that has HOSTILE capability
     * You can do something else with this method.
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return list of actions
     * @see Status#HOSTILE_TO_ENEMY
     */
    @Override
	public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {
        Actions actions = new Actions();
//
//        if(followBehaviour == null){
//            this.followBehaviour = new FollowBehaviour(otherActor);
//            behaviours.add(followBehaviour);
//        }

		// it can be attacked only by the HOSTILE opponent, and this action will not attack the HOSTILE enemy back.
        if (hasCapability(Abilities.RANGE_ATTACK)){
            RangeAttack rangeAttack = new RangeAttack(otherActor);
            behaviours.add(rangeAttack);
            FollowBehaviour followBehaviour = new FollowBehaviour(otherActor);
            behaviours.add(followBehaviour);
        }

        if (!otherActor.hasCapability(Status.CHARGE)){
            actions.add(new AttackAction(this,direction));
        }

        // it can be attack player in long range
        if(!this.hasCapability(Abilities.RANGE_ATTACK) && otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)) {
            removeCapability(Status.WANDER);
            AttackAction attackAction = new AttackAction(otherActor);
            behaviours.add(attackAction);
            FollowBehaviour followBehaviour = new FollowBehaviour(otherActor);
            behaviours.add(followBehaviour);
        }
		return actions;
	}

    /**
     * print in console
     * @return  Enemy name and stats
     */
    @Override
    public String toString() {
        return name + "(" + hitPoints + "/" + maxHitPoints + ") (" + getWeapon() + ")";
    }

    /**
     * get the enemy soul
     * @return  enemy soul amount
     */
    public int getSoul() {
        return soul;
    }

    /**
     * Transfer current souls to another soul entity.
     * This implementation hides "getter of soullevel" and make it as a `behaviour` method.
     * @param soulObject in this scenario, it is an Enemy
     */
    public void transferSouls(Soul soulObject) {
        soulObject.addSouls(soul);
    }
}
