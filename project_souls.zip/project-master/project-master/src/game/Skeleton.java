package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;
import game.enums.Status;
import game.interfaces.Resettable;

import java.util.Random;
/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * class for skeleton
 */
public class Skeleton extends Enemy implements Resettable {
    private Random random = new Random();
    boolean choice;
    private Location initial;
    /**
     * Constructor.
     * All Undeads are represented by an 'u' and have 30 hit points.
     * @param name the name of this Undead
     */
    public Skeleton(String name,Location initial) {
        super(name, 's', 100, 250);
        behaviours.add(0,new WanderBehaviour());
        choice = random.nextBoolean();
        this.addCapability(Abilities.REVIVE);
        registerInstance();
        this.initial = initial;
        this.addCapability(Status.WANDER);
    }

    /**
     * the action that skeleton can do in this turn
     * @see edu.monash.fit2099.engine.Actor#playTurn(Actions, Action, GameMap, Display)
     */

    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        // loop through all behaviours
        if (!isConscious()){
            if (hasCapability(Abilities.REVIVE)){
                if ((random.nextInt(100) <= 50)){   // 50% chance to revive the skeleton
                    removeCapability(Abilities.REVIVE);
                    heal(Integer.MAX_VALUE);
                    ReviveAction reviveAction = new ReviveAction(map.locationOf(this),this);
                    return reviveAction;
                }
            }
            return new RemoveActorAction();
        }
        if (hasCapability(Abilities.RESET)){
            RespawnAction respawnAction = new RespawnAction(initial);   //reset the skeleton
        }
        return super.playTurn(actions, lastAction, map, display);
    }

    /**
     * get skeleton weapon
     * @return  randomly get broad sword or giant axe
     */
    @Override
    public Weapon getWeapon() {
        Weapon weapon = null;
        if(choice)
            weapon = new BroadSword();
        else
            weapon = new GiantAxe();
            this.addCapability(Abilities.ACTIVE_SKILL);
        return weapon;
    }

    /**
     * reset the skeleton (heal back its hitpoint)
     */
    @Override
    public void resetInstance() {
        hitPoints = maxHitPoints;
        addCapability(Abilities.RESET);
        behaviours.clear();
        behaviours.add(new WanderBehaviour());
    }

    /**
     * permanent add it to resettable list
     * @return
     */
    @Override
    public boolean isExist() {
        return true;
    }
}
