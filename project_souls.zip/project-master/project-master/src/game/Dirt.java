package game;

import edu.monash.fit2099.engine.Ground;
import game.enums.Status;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A class that represents bare dirt.
 */
public class Dirt extends Ground {
	/**
	 * constructor for dirt
	 */
	public Dirt() {
		super('.');
		this.addCapability(Status.DIRT);
	}
}
