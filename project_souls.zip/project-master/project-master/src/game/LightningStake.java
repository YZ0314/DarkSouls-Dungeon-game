package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.enums.Status;

/**
 * A magic that deal damage and stun target for 1 round
 */
public class LightningStake extends Action {
    private Actor target;   // target
    private int damage;

    /**
     * Constructor
     * @param target
     */
    public LightningStake(Actor target) {
        this.target = target;
        this.damage = 60;
    }

    /**
     * method that stun actor and hurt the actor. If target die, return a target is kill statement and active the
     * dying action
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return  result statement
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String result = actor + " cast Lightning Stake on " + target + " deal " + damage + " damage.";
        target.addCapability(Status.STUN);
        target.hurt(damage);
        if (!target.isConscious()){
            DyingAction dyingAction = new DyingAction(target);
            dyingAction.execute(actor,map);
            return result + "\n" + target + " is killed";
        }
        return result;
    }

    /**
     * allow actor to perform lightning stake action
     * @param actor The actor performing the action.
     * @return display action in console menu
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Cast Lightning Stake";
    }
}
