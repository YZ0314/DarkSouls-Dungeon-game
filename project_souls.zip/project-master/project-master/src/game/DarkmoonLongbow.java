package game;

import edu.monash.fit2099.engine.*;
import game.enums.Status;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A weapon for AldrichTheDevourer extends GameWeaponItem
 */
public class DarkmoonLongbow extends GameWeaponItem {
    protected Random random = new Random(); // a random number
    protected Display display = new Display();
    private Actor holder;   // holder for this weapon
    ArrayList<Location> locations = new ArrayList<Location>();  //store the array for the actor
    /**
     * Constructor.
     */
    public DarkmoonLongbow() {
        super("Darkmoon Longbow", 'D', 70, "strike", 80, 0);
    }

    /**
     * method for calculate the damage for Weapon (maybe cause Critical Strike)
     * @return  the damage for the Weapon
     */
    @Override
    public int damage() {
        if ( random.nextInt(100) <= 15){
            display.println("Critical Strike!!!");
            return damage * 2;
        }
        return damage;
    }

    /**
     * find the targer and store it into arraylist
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        holder = actor;
        Location here = currentLocation;
        GameMap map = here.map();
        NumberRange xs, ys;
        xs = new NumberRange(here.x() -3 , 7);
        ys = new NumberRange(here.y() -3 , 7);
        for (int x : xs) {
            for (int y : ys) {
                if (map.at(x,y).containsAnActor() && map.at(x,y).getActor().hasCapability(Status.HOSTILE_TO_ENEMY)) {
                    locations.add(map.at(x, y));
                }
            }
        }
    }

    /**
     * return the holder can allowable action (Range Attack)
     * @return
     */
    @Override
    public List<Action> getAllowableActions() {
        Actions actions = new Actions();
        for (Location location : locations){
            if (location.containsAnActor() && location.getActor().hasCapability(Status.HOSTILE_TO_ENEMY)){
                holder.getAllowableActions(location.getActor(), "", location.map());
            }
        }
        locations.clear();
        return actions.getUnmodifiableActionList();
    }
}
