package game;

import edu.monash.fit2099.engine.*;

import java.util.Random;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A class that represents a cemetery where the undead spawn.
 */
public class Cemetery extends Ground {
    /**
     * constructor for the cemetery display
     */
    public Cemetery() {
        super('c');
    }

    /**
     * Allow actor to enter this location
     * @param actor the Actor to check
     * @return  false no one can enter
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
    }

    /**
     * 25% chances to create undead from the cemetery
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        Random random = new Random();
        if(random.nextInt(100) <= 25){
            location.addActor(new Undead("Undead"));
        }
    }
}
