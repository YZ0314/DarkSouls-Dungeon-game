package game;

import edu.monash.fit2099.engine.*;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A class for giant axe that extend Melee Weapon
 */
public class GiantAxe extends MeleeWeapon {

    /**
     * Constructor for giant Axe
     */
    public GiantAxe() {
        super("GiantAxe", 'g', 50, "hits", 80,1000);
    }

    /**
     * damage that giant axe can deal
     * @return  The damage of the giant axe
     */
    @Override
    public int damage() {
        return damage;
    }

    /**
     * method to activate the spin attack
     * @param target the actor
     * @param direction the direction of target, e.g. "north"
     * @return  spin attack for the actor
     */
    @Override
    public WeaponAction getActiveSkill(Actor target, String direction) {
            SpinAction spinAction = new SpinAction(this);
            return  spinAction;
    }
}
