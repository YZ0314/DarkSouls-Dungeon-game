package game;

import edu.monash.fit2099.engine.Actor;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * Ashen Estus Flask item for player
 */
public class AshenEstusFlask extends Potion {

    /**
     * Constructor of Ashen Estus Flask
     */
    public AshenEstusFlask() {
        super("Ashen Estus Flask", 3, 3);
    }

    /**
     * The process of increasing magic points of actor
     * @param actor the actor that is consuming the ashen estus flask
     * @return displays message of actor consuming drink or not
     */
    @Override
    public String consumedBy(Actor actor) {
        if (this.chargeNum>0){
            ((Player) actor).restoreMP(40);
            reduceChargeNum();
            return actor +" drinks the Ashen Estus Flask" ;
        }
        return "Ashen Estus Flask run out of charge";
    }
}
