package game;

import edu.monash.fit2099.engine.*;
import game.enums.Status;

/**
 * A active skill for the Fire Link Great Sword
 */
public class EmberAction extends WeaponAction {
    /**
     * Constructor
     * @param weaponItem the weapon item that has capabilities
     */
    public EmberAction(WeaponItem weaponItem) {
        super(weaponItem);
    }

    /**
     * Get the target location then deal damage, burn ground and stun target for 1 round
     * @param actor the actor performing action
     * @param map current map
     * @return  A statement with the damage and target if it hit
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        Location here = map.locationOf(actor);
        String result = "";
        actor.addCapability(Status.COOLDOWN);
        int damage = 0;
        for (Exit exit : here.getExits()) {
            Location destination = exit.getDestination();   // get actor direction
            if (destination.containsAnActor()) {
                damage = actor.getWeapon().damage()*2;  //
                result += destination.getActor();
                destination.getActor().hurt(damage);
                destination.getActor().addCapability(Status.STUN);
            }
            if (destination.getGround().hasCapability(Status.DIRT)){
                destination.setGround(new BurnGround());
            }
        }
        if (result != ""){
            return result + "get hits " + damage + " damage by " + actor +"(EMBER)" ;
        }
        return actor + "activate EMBER";
    }

    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
