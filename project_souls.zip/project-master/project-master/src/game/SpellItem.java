package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;
import game.interfaces.Purchasable;

/**
*	@author: KAM LUNG YIM
* 	@author: Trinna De Guzman
* 	@author: Ivan He
*
*	@Version: 1.0.0
* 	@last updated: 26/09/2021
*/

/**
 * A Spell Item class to unlock magic spells
 */
public class SpellItem extends Item implements Purchasable {
    private int cost;

    /**
     * Constructor for spell item
     */
    public SpellItem() {
        super("Spell Item", 'T', false);
        this.cost = 500;
    }

    /**
     * To get the cost of Spell item
     * @return cost of item
     */
    @Override
    public int getCost() {
        return cost;
    }

    /**
     * The actor will be able to buy Spell Item
     * @param actor the actor that buys the spell
     * @param map the map the actor is in
     * @return message displaying if item is bought
     */
    @Override
    public String getPurchase(Actor actor, GameMap map) {
        actor.addItemToInventory(this);
        actor.addCapability(Abilities.CAST_SPELL);
        return actor + " bought the " + name + ". Magic spells can be bought from now.";
    }
}
