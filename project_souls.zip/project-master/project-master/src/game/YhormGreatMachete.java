package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.WeaponAction;
import game.enums.Status;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * Class for yhorm Great Machete
 */
public class YhormGreatMachete extends MeleeWeapon{

    /**
     * Constructor.
     */
    public YhormGreatMachete() {
        super("Yhorm’s Great Machete",'M',95,"hits",60,0);
    }

    /**
     * Yhorm Greay Machete active skill
     * @param target the target actor
     * @param direction the direction of target, e.g. "north"
     * @return  burn ground action
     */
    @Override
    public WeaponAction getActiveSkill(Actor target, String direction) {
            return new BurnAction(this);
    }

    /**
     * if yhorm in ember form increase the hit rate
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        if (actor.hasCapability(Status.EMBER)){
            hitRate = 90;
        }
    }
}
