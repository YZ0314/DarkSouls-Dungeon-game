package game;

import edu.monash.fit2099.engine.Item;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * Base class for any item that can be picked up and dropped.
 */
public class PortableItem extends Item {
	public PortableItem(String name, char displayChar) {
		super(name, displayChar, true);
	}
}
