package game;

import edu.monash.fit2099.engine.*;
import game.enums.Status;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * The gorge or endless gap that is dangerous for the Player.
 */
public class Valley extends Ground {
	/**
	 * Constructor
	 */
	public Valley() {
		super('+');
	}

	/**
	 * Valley that only player can enter.
	 * @param actor the Actor to check
	 * @return false or actor cannot enter.
	 */
	@Override
	public boolean canActorEnter(Actor actor){
		return actor.hasCapability(Status.HOSTILE_TO_ENEMY);
	}

	/**
	 * check whether the player in the valley, if yes kill the player
	 * @param location The location of the Ground
	 */
	@Override
	public void tick(Location location){
		if (location.containsAnActor()) {
			location.getActor().hurt(Integer.MAX_VALUE);
			System.out.println(location.getActor() + " stepped on the Valley");
		}
	}
}
