package game;

import edu.monash.fit2099.engine.*;
import game.enums.Status;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * wind slash  action for storm ruler
 */
public class WindSlash extends WeaponAction {
    protected Actor target;

    /**
     * Constructor
     * @param weaponItem
     * @param target
     */
    public WindSlash(WeaponItem weaponItem, Actor target) {
        super(weaponItem);
        this.target = target;
    }

    /**
     * action perform Wind Slash
     * @param actor player who have full charged
     * @param map   map that where actor in
     * @return  print statement if it is activated
     */
    @Override
    public String execute(Actor actor, GameMap map){
        int damage = weapon.damage()*2;
        String result = actor + " " + weapon.verb() + " " + target + " for " + damage + " damage (Wind Slash).";
        target.hurt(damage);
        if (!target.isConscious()){
            DyingAction dyingAction = new DyingAction(target);
            dyingAction.execute(actor,map);
        }
        actor.removeCapability(Status.FULL_CHARGE);
        target.addCapability(Status.STUN);
        return result;
    }

    @Override
    public String menuDescription(Actor actor) {
        return "Wind Slash";
    }
}
