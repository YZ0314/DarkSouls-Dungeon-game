package game;

import edu.monash.fit2099.engine.*;
import game.enums.Status;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * class for storm ruler
 */
public class StormRuler extends MeleeWeapon{
    protected Random random = new Random();
    protected Display display = new Display();
    private int roundTurn; // counter
    private Actor holder;
    ArrayList<Location> locations = new ArrayList<Location>();

    /**
     * constructor
     */
    public StormRuler() {
        super("StormRuler", '7', 70, "hits", 60,2000);
        roundTurn = 0;
    }

    /**
     * calculate the damage of the storm ruler if critical strike damage *2
     * @return  damage of the storm ruler
     */
    @Override
    public int damage() {
        if (random.nextInt(100) <= 20 && !this.hasCapability(Status.SKILL_ATTACK)){
            display.println("Critical Strike!!!");
            return damage*2;
        }
        return damage;
    }

    /**
     * action that allow actor to pick up storm ruler
     * @param actor an actor that will interact with this item
     * @return  swap the weapon
     */
    @Override
    public PickUpItemAction getPickUpAction(Actor actor) {
        SwapWeaponAction swapWeaponAction = new SwapWeaponAction(this);
        return swapWeaponAction;
    }

    /**
     * A counter for the round turn
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        holder = actor;
        Location here = currentLocation;
        GameMap map = here.map();
        for (Exit exit : here.getExits()) {
            Location destination = exit.getDestination();
            if (destination.containsAnActor() && destination.getActor() instanceof YhormTheGiant) {
                locations.add(destination);
            }
        }
        if (actor.hasCapability(Status.CHARGE)){
            if (roundTurn < 3){
                roundTurn++;   //round + 1 if it less than 3
            }
        }
        // set it back to 0
        if (!actor.hasCapability(Status.CHARGE) && !actor.hasCapability(Status.FULL_CHARGE)){
            roundTurn = 0;
            actor.removeCapability(Status.FULL_CHARGE);
            this.removeCapability(Status.SKILL_ATTACK);
            }
    }

    /**
     * a active skill for the storm ruler
     * @param target the actor
     * @param direction the direction of target, e.g. "north"
     * @return  A charge action if it is not charge and return full charge if round turn is 3
     */
    @Override
    public WeaponAction getActiveSkill(Actor target, String direction) {
        if (target.hasCapability(Status.CHARGE) || target.hasCapability(Status.FULL_CHARGE)){
            if (roundTurn == 3){
                target.removeCapability(Status.CHARGE);
                target.addCapability(Status.FULL_CHARGE);
                this.addCapability(Status.SKILL_ATTACK);
                display.println("Wind Slash is almost fully charged (next turn)");
            }
            return null;
        }
        ChargeAction chargeAction = new ChargeAction(this);
        return chargeAction;
    }

    /**
     * show the storm ruler with it round turn of charge
     * @return  storm ruler statement
     */
    @Override
    public String toString() {
        return  name + " (" + roundTurn + "/3)";
    }

    @Override
    public List<Action> getAllowableActions() {
        Actions actions = new Actions();
        for (Location location : locations){
            if (location.containsAnActor() && location.getActor() instanceof YhormTheGiant &&
                    holder.hasCapability(Status.FULL_CHARGE)){
                    actions.add(new WindSlash(this,location.getActor()));
            }
        }
        locations.clear();
        return actions.getUnmodifiableActionList();
    }
}
