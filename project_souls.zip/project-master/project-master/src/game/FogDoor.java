package game;

import edu.monash.fit2099.engine.*;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * The Fog Dorr for player to move across different maps.
 */
public class FogDoor extends Ground {

    /**
     * private attributes storing the location and direction of player
     */
    private Location location;
    private String direction;

    /**
     * A constructor for the Fog door class
     * @param location the player's current location
     * @param direction the direction where player aims to move to
     */
    public FogDoor(Location location, String direction) {
        super('=');
        this.location = location;
        this.direction = direction;
    }

    /**
     * An action method that allows actor to move to a new location
     * @param actor the Actor interacting with the fog door
     * @param location the current Location
     * @param direction the direction where actor wants to move to
     * @return return the moving action of actor
     */
    @Override
    public Actions allowableActions(Actor actor, Location location, String direction) {
        Actions actions = new Actions();
        actions.add(new MoveActorAction(this.location, this.direction));
        return actions;
    }
}
