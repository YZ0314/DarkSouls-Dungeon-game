package game;

import java.util.ArrayList;
import java.util.Random;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Exit;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;
import game.enums.Status;
import game.interfaces.Behaviour;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A class for wander behaviour
 */
public class WanderBehaviour extends Action implements Behaviour {
	
	private final Random random = new Random();

	/**
	 * Returns a MoveAction to wander to a random location, if possible.  
	 * If no movement is possible, returns null.
	 * 
	 * @param actor the Actor enacting the behaviour
	 * @param map the map that actor is currently on
	 * @return an Action, or null if no MoveAction is possible
	 */
	@Override
	public Action getAction(Actor actor, GameMap map) {
		ArrayList<Action> actions = new ArrayList<Action>();
		
		for (Exit exit : map.locationOf(actor).getExits()) {
            Location destination = exit.getDestination();
            if (destination.canActorEnter(actor)) {
            	actions.add(exit.getDestination().getMoveAction(actor, "around", exit.getHotKey()));

            }
        }
		
		if (!actions.isEmpty() && actor.hasCapability(Status.WANDER)) {
			return actions.get(random.nextInt(actions.size()));
		}
		else{
			return null;
		}
	}

	/**
	 * nothing
	 * @param actor The actor performing the action.
	 * @param map The map the actor is on.
	 * @return nothing
	 */
	@Override
	public String execute(Actor actor, GameMap map) {
		return menuDescription(actor);
	}

	/**
	 * print raagrh
	 * @param actor The actor performing the action.
	 * @return raagrh
	 */
	@Override
	public String menuDescription(Actor actor) {
		return "Raagrh...";
	}
}
