package game;

import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * set the ground to fire
 */
public class BurnGround extends Ground {
    int current = 0; // set the current round to be 0

    /**
     * constructor for Burn Ground
     */
    public BurnGround() {
        super('V');
    }

    /**
     * method to count the ground to burn for 3 rounds and hurt player 25 hitpoint if player stand in the fire per round
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        if (current > 3) {
            location.setGround(new Dirt());
        }
        if (location.containsAnActor()) {
            if (!(location.getActor() instanceof LordOfCinder)) {
                location.getActor().hurt(25);
            }
        }
        current++;
    }
}
