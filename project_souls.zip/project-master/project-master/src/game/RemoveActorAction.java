package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;

/**
 * Action that remove actor
 */
public class RemoveActorAction extends Action {
    /**
     * Return actor die statement and remove it from the map
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        map.removeActor(actor);
        if (actor instanceof LordOfCinder){
            return "   ____   _______      ___________   __________ ________          ________        _      ____     ____     \n" +
                    "  6MMMMb/ `MM'`MM\\     `M'`MMMMMMMb. `MMMMMMMMM `MMMMMMMb.        `MMMMMMM       dM.     `MM'     `MM'     \n" +
                    " 8P    YM  MM  MMM\\     M  MM    `Mb  MM      \\  MM    `Mb         MM    \\      ,MMb      MM       MM      \n" +
                    "6M      Y  MM  M\\MM\\    M  MM     MM  MM         MM     MM         MM           d'YM.     MM       MM      \n" +
                    "MM         MM  M \\MM\\   M  MM     MM  MM    ,    MM     MM         MM   ,      ,P `Mb     MM       MM      \n" +
                    "MM         MM  M  \\MM\\  M  MM     MM  MMMMMMM    MM    .M9         MMMMMM      d'  YM.    MM       MM      \n" +
                    "MM         MM  M   \\MM\\ M  MM     MM  MM    `    MMMMMMM9'         MM   `     ,P   `Mb    MM       MM      \n" +
                    "MM         MM  M    \\MM\\M  MM     MM  MM         MM  \\M\\           MM         d'    YM.   MM       MM      \n" +
                    "YM      6  MM  M     \\MMM  MM     MM  MM         MM   \\M\\          MM        ,MMMMMMMMb   MM       MM      \n" +
                    " 8b    d9  MM  M      \\MM  MM    .M9  MM      /  MM    \\M\\         MM        d'      YM.  MM    /  MM    / \n" +
                    "  YMMMM9  _MM__M_      \\M _MMMMMMM9' _MMMMMMMMM _MM_    \\M\\_      _MM_     _dM_     _dMM__MMMMMMM _MMMMMMM \n" +
                    "                                                                                                           ";
        }
        return actor + " has died";
    }

    /**
     * not in use
     * @param actor The actor performing the action.
     * @return null
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
