package game;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Item;
import game.interfaces.Consumable;
import game.interfaces.Resettable;

/**
    Potion item for player
 */
public abstract class Potion extends Item implements Resettable, Consumable {

    protected int chargeNum;  // charge of the Estus Flask
    protected int MaxchargeNum;   // Maximum charge of the Estus Flask
    protected String potionName;
    /***
     * Constructor.
     */
    public Potion(String potionName, int chargeNum, int maxChargeNum) {
        super("E",'e',false);
        this.potionName = potionName;
        this.chargeNum=chargeNum;
        this.MaxchargeNum=maxChargeNum;
        this.registerInstance();
        allowableActions.add(new ConsumeAction(potionName,this ));

    }

    /**
     * get the number of charge of the potions
     * @return  number of charge of the potions
     */
    public int getChargeNum() {
        return chargeNum;
    }

    /**
     * get the maximum charge of the Estus Flask
     * @return  maximum charge of the Estus Flask
     */
    public int getMaxchargeNum() {
        return MaxchargeNum;
    }

    /**
     * reduce the charge of the potions once it uses

     */
    public void reduceChargeNum(){
        if (this.chargeNum>0)  {
            this.chargeNum-=1;
        }
    }

    /**
     * reset the potions
     */
    @Override
    public void resetInstance() {
        this.chargeNum=MaxchargeNum;
    }

    /**
     * allow it permanent store in the reset list
     * @return boolean
     */
    @Override
    public boolean isExist() {
        return true;
    }

    /**
     * not used
     * @param actor the actor that is consuming items
     * @return null
     */
    @Override
    public String consumedBy(Actor actor) {
        return null;
    }

    /**
     * The full name of the potions
     * @return display full name of potions
     */
    @Override
    public String getConsumeName() {
        return "("+this.chargeNum+"/"+ this.MaxchargeNum+")";
    }
}