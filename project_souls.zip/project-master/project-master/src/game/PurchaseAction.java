package game;

import edu.monash.fit2099.engine.*;
import game.interfaces.Purchasable;
import game.interfaces.Soul;
/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A buying action that allow player to buy item
 */
public class PurchaseAction extends Action implements Soul {

    protected Purchasable item; // weapon that able to buy
    Display display;    // print in the console

    /**
     * A constructor for buy action
     */
    public PurchaseAction(Purchasable item) {
        this.item = item;
    }

    /**
     * To determine whether the actor able to buy the weapon if yes reduce the soul and get purchasable item
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return  a statement that print whether the transaction is success
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (actor.asSoul().subtractSouls(this.item.getCost())) {
            return "Transaction is successful\n" + item.getPurchase(actor,map);
        }
        return "Transaction is fails, Player does not have enough souls";
    }

    /**
     * print the item that able to buy in the menu
     * @param actor The actor performing the action.
     * @return  return item in the menu
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Buy item: " + item.toString() + " (" + item.getCost() + " Souls)";
    }

    /**
     * no use
     * @param soulObject a target souls.
     */
    @Override
    public void transferSouls(Soul soulObject) {

    }

    /**
     * no use
     * @param souls number of souls to be incremented.
     * @return
     */
    @Override
    public boolean addSouls(int souls) {
        return Soul.super.addSouls(souls);
    }

    /**
     * no use
     * @param souls number souls to be deducted
     * @return
     */
    @Override
    public boolean subtractSouls(int souls) {
        return Soul.super.subtractSouls(souls);
    }
}
