package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.enums.Status;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A rest Action for bonfire
 */
public class RestAction extends Action {
    /**
     * constructor
     */
    private String currentBonfire;
    public RestAction(String bonfireName) {
        this.currentBonfire=bonfireName;
    }

    /**
     * run rest manger to reset Everything
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return statement to notice player have rested
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        actor.addCapability(Status.LIGHTING);
        ResetManager.getInstance().run();// reset Everything
        return "Player has Rested";
    }

    /**
     * print in the console to allow player use this action
     * @param actor The actor performing the action.
     * @return  rest at bonfire
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Rest at "+ currentBonfire+" bonfire";
    }
}
