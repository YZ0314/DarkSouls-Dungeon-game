package game;

import edu.monash.fit2099.engine.Actor;
import game.enums.Abilities;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A Carthus Flame Arc class for a Spell Magic
 */
public class CarthusFlameArc extends SpellMagic {

    /***
     * Constructor of Replenish magic class
          */
    public CarthusFlameArc() {
        super("Carthus Flame Arc",'*',false,1000, 100);
    }

    /**
     * The capability given to actor to activate the spell
     * @param actor the actor that uses the Carthus Flame Arc spell
     * @return message if spell is used
     */
    @Override
    public String spellBy(Actor actor) {
        actor.addCapability(Abilities.INCREASE_DAMAGE);
        return "Activate Carthus Flame Arc!";
    }
}
