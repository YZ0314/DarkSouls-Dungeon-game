package game;

import edu.monash.fit2099.engine.*;
import game.interfaces.Purchasable;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * MeleeWeapon for the weapon
 */
public class MeleeWeapon extends WeaponItem implements Purchasable {
    private int cost;   // cost of the weapon
    /**
     * Constructor.
     *
     * @param name        name of the item
     * @param displayChar character to use for display when item is on the ground
     * @param damage      amount of damage this weapon does
     * @param verb        verb to use for this weapon, e.g. "hits", "zaps"
     * @param hitRate     the probability/chance to hit the target.
     */
    public MeleeWeapon(String name, char displayChar, int damage, String verb, int hitRate,int cost) {
        super(name, displayChar, damage, verb, hitRate);
        this.cost = cost;
        portable = false;
    }

    /**
     * get the cost of the weapon
     * @return  cost of the weapon
     */
    public int getCost() {
        return cost;
    }

    /**
     * The actor will be able to swap new weapon with current weapon
     * @param actor the actor that buys the weapon
     * @param map the map the actor is in
     * @return message displaying if weapon item is bought
     */
    @Override
    public String getPurchase(Actor actor, GameMap map) {
        Weapon currentWeapon = actor.getWeapon();
        SwapWeaponAction swapWeapon = new SwapWeaponAction(this);
        swapWeapon.execute(actor, map);
        return actor + " swapped " + currentWeapon + " with " + name;
    }
}
