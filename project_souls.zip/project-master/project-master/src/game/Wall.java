package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Ground;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A class for wall in the map
 */
public class Wall extends Ground {
	/**
	 * Constructor
	 */
	public Wall() {
		super('#');
	}

	/**
	 * no one can enter the wall
	 * @param actor the Actor to check
	 * @return false
	 */
	@Override
	public boolean canActorEnter(Actor actor) {
		return false;
	}

	/**
	 * wall can block the object
	 * @return
	 */
	@Override
	public boolean blocksThrownObjects() {
		return true;
	}
}
