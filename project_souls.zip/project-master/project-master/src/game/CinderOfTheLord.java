package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.PickUpItemAction;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * Class that extends Item and store into each Lord Of Cinder inventory
 */
public class CinderOfTheLord extends Item {
    private String name;
    /***
     * Constructor.
     */
    public CinderOfTheLord(String name,Actor owner) {
        super("Cinder Of The Lord (Corpse)", '%', true);
        this.name = name;
    }

    /**
     * If actor Pick it up, it will disappear in the map
     * @param actor an actor that will interact with this item
     * @return
     */
    @Override
    public PickUpItemAction getPickUpAction(Actor actor) {
        PickUpItemAction pickUpItemAction = new PickUpItemAction(this);
        actor.addItemToInventory(this);
        portable = false;
        return pickUpItemAction;
    }
}
