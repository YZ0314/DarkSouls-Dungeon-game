package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.DropItemAction;
import edu.monash.fit2099.engine.WeaponItem;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * Weapon that extend the weapon item
 */
public class GameWeaponItem extends WeaponItem {
    private int cost;
    /**
     * Constructor.
     *
     * @param name        name of the item
     * @param displayChar character to use for display when item is on the ground
     * @param damage      amount of damage this weapon does
     * @param verb        verb to use for this weapon, e.g. "hits", "zaps"
     * @param hitRate     the probability/chance to hit the target.
     */
    public GameWeaponItem(String name, char displayChar, int damage, String verb, int hitRate, int cost) {
        super(name, displayChar, damage, verb, hitRate);
        this.cost = cost;
    }

    /**
     * get the cost of the weapon
     * @return   weapon's cost
     */
    public int getCost() {
        return cost;
    }

    /**
     * In this game, player has to hold a weapon, it cannot be dropped
     * @param actor an actor that will interact with this item
     * @return null because player is not able to drop the wepaon
     */
    @Override
    public DropItemAction getDropAction(Actor actor) {
        return null;
    }
}

