package game;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;
import game.enums.Status;

/**
 *  A boss that extends Lord of Cinder
 */
public class SoulOfCinder extends LordOfCinder {
    private Location initial;   // inital location
    /**
     * Constructor.
     *
     * @param name name of actor
     * @param displayChar the character of Actor
     * @param hitPoints the number of hitpoints the actor has
     */
    public SoulOfCinder(String name, char displayChar, int hitPoints, Location initial) {
        super(name, displayChar, hitPoints);
        addCapability(Abilities.REVIVE);
        addItemToInventory(new FireLinkGreatSword());
        addCapability(Abilities.CAST_SPELL);
        this.initial = initial;
    }

    /**
     * action that actor can do in the play turn
     * @param actions actions of the actor
     * @param lastAction the previous action of the actor
     * @param map current map
     * @param display display message of actions performed
     * @return  actions in this round
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        // revive if actor don't have ember form
        if (!isConscious() && !hasCapability(Status.EMBER)){
            addCapability(Status.EMBER);
            heal(maxHitPoints);
            addCapability(Abilities.ACTIVE_SKILL);
            removeCapability(Abilities.CAST_SPELL);
            BurnAction burnAction = new BurnAction(new FireLinkGreatSword());
            burnAction.execute(this,map);
            display.println("__________ ___       ___________   __________ ________          ________    ____    ________    ___       ___\n" +
                    "`MMMMMMMMM `MMb     dMM'`MMMMMMMb. `MMMMMMMMM `MMMMMMMb.        `MMMMMMM   6MMMMb   `MMMMMMMb.  `MMb     dMM'\n" +
                    " MM      \\  MMM.   ,PMM  MM    `Mb  MM      \\  MM    `Mb         MM    \\  8P    Y8   MM    `Mb   MMM.   ,PMM \n" +
                    " MM         M`Mb   d'MM  MM     MM  MM         MM     MM         MM      6M      Mb  MM     MM   M`Mb   d'MM \n" +
                    " MM    ,    M YM. ,P MM  MM    .M9  MM    ,    MM     MM         MM   ,  MM      MM  MM     MM   M YM. ,P MM \n" +
                    " MMMMMMM    M `Mb d' MM  MMMMMMM(   MMMMMMM    MM    .M9         MMMMMM  MM      MM  MM    .M9   M `Mb d' MM \n" +
                    " MM    `    M  YM.P  MM  MM    `Mb  MM    `    MMMMMMM9'         MM   `  MM      MM  MMMMMMM9'   M  YM.P  MM \n" +
                    " MM         M  `Mb'  MM  MM     MM  MM         MM  \\M\\           MM      MM      MM  MM  \\M\\     M  `Mb'  MM \n" +
                    " MM         M   YP   MM  MM     MM  MM         MM   \\M\\          MM      YM      M9  MM   \\M\\    M   YP   MM \n" +
                    " MM      /  M   `'   MM  MM    .M9  MM      /  MM    \\M\\         MM       8b    d8   MM    \\M\\   M   `'   MM \n" +
                    "_MMMMMMMMM _M_      _MM__MMMMMMM9' _MMMMMMMMM _MM_    \\M\\_      _MM_       YMMMM9   _MM_    \\M\\__M_      _MM_\n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "                                                                                                             \n" +
                    "       _         ____   __________ ________     ___        _      __________ __________ ________             \n" +
                    "      dM.       6MMMMb/ MMMMMMMMMM `MM'`Mb(     )d'       dM.     MMMMMMMMMM `MMMMMMMMM `MMMMMMMb.           \n" +
                    "     ,MMb      8P    YM /   MM   \\  MM  YM.     ,P       ,MMb     /   MM   \\  MM      \\  MM    `Mb           \n" +
                    "     d'YM.    6M      Y     MM      MM  `Mb     d'       d'YM.        MM      MM         MM     MM           \n" +
                    "    ,P `Mb    MM            MM      MM   YM.   ,P       ,P `Mb        MM      MM    ,    MM     MM           \n" +
                    "    d'  YM.   MM            MM      MM   `Mb   d'       d'  YM.       MM      MMMMMMM    MM     MM           \n" +
                    "   ,P   `Mb   MM            MM      MM    YM. ,P       ,P   `Mb       MM      MM    `    MM     MM           \n" +
                    "   d'    YM.  MM            MM      MM    `Mb d'       d'    YM.      MM      MM         MM     MM           \n" +
                    "  ,MMMMMMMMb  YM      6     MM      MM     YM,P       ,MMMMMMMMb      MM      MM         MM     MM           \n" +
                    "  d'      YM.  8b    d9     MM      MM     `MM'       d'      YM.     MM      MM      /  MM    .M9           \n" +
                    "_dM_     _dMM_  YMMMM9     _MM_    _MM_     YP      _dM_     _dMM_   _MM_    _MMMMMMMMM _MMMMMMM9'           \n" +
                    "                                                                                                  ");
        }
        // Actor can't revive anymore
        if(!isConscious() && hasCapability(Status.EMBER)){
            return new RemoveActorAction();
        }

        // if resetManger is called
        if (hasCapability(Abilities.RESET)){
            RespawnAction respawnAction = new RespawnAction(initial);   // respawn to initial location
            return respawnAction;
        }
        return super.playTurn(actions, lastAction, map, display);
    }

    /**
     * heal method for Soul of Cinder
     * @param points number of hitpoints to add.
     */
    @Override
    public void heal(int points) {
        hitPoints = points;
    }

    /**
     * action that will be happen for actor if resetManger is call
     */
    @Override
    public void resetInstance() {
        heal(maxHitPoints);
        removeCapability(Status.EMBER);
        removeCapability(Abilities.ACTIVE_SKILL);
        addCapability(Abilities.RESET);
    }
}
