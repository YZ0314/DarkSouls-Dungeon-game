package game;

import edu.monash.fit2099.engine.*;
import game.enums.Status;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * An Active Skill that allow actor to burn the dirt
 */
public class BurnAction extends WeaponAction {
    /**
     * constructor for Burn Ground Action
     * @param weaponItem    weapon that can activate this action
     */

    public BurnAction(WeaponItem weaponItem) {
        super(weaponItem);
    }

    /**
     * Action that get the dirt to burn
     * @param actor the actor that activate this action
     * @param map   The GameMap that effect by the action
     * @return  result with actor active Burn Ground
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        Location here = map.locationOf(actor);
        String result = "";
        for (Exit exit : here.getExits()) {
            Location destination = exit.getDestination();
            if (destination.getGround().hasCapability(Status.DIRT)){
                destination.setGround(new BurnGround());
            }
        }
        return actor + " active Burn Ground";
    }

    /**
     * Don't have to use it
     * @param actor
     * @return nothing
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
