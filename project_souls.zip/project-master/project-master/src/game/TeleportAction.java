package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;

/**
 * A teleportaction for the bonfire
 */
public class TeleportAction extends Action {
    private Bonfire bonfire;    //the bonfire that want to go
    private Location location;  // location of the bonfire

    public TeleportAction(Bonfire bonfire, Location location) {
        this.bonfire = bonfire;
        this.location = location;
    }

    /**
     * Teleport actor to the bonfire they want
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return  Statement to notice actor has teleport
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        map.moveActor(actor,location);  // move actor to bonfire
        return "Actor have teleported to "+ bonfire.bonfireName;
    }

    /**
     * A statement that print in menu allow player to choose
     * @param actor The actor performing the action.
     * @return  statement move actor to the bonfire
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " moves to " + bonfire.bonfireName;
    }
}
