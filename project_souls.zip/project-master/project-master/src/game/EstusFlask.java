package game;

import edu.monash.fit2099.engine.Actor;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
    Estus Flask item for player
 */
public class EstusFlask extends Potion {

    /***
     * Constructor of estus flask
     */
    public EstusFlask() {
        super("Estus Flask", 3,3);
    }

    /**
     * The process of increasing hit points of actor
     * @param actor the actor that is consuming the estus flask
     * @return displays message of actor consuming drink or not
     */
    @Override
    public String consumedBy(Actor actor) {
        if (this.chargeNum > 0) {
            actor.heal(40);
            reduceChargeNum();
            return actor + " drinks the Estus Flask";
        }
        return "Estus Flask run out of charges";
    }
}