package game;

import edu.monash.fit2099.engine.*;
import game.enums.Status;

/**
 * Class for player to active the bonfire
 */
public class ActiveAction extends Action {
    private Bonfire bonfire;    // Bonfire

    /**
     * Constructor
     * @param bonfire to save the bonfire
     */
    public ActiveAction(Bonfire bonfire) {
        this.bonfire=bonfire;
    }

    /**
     * if bonfire is not lighting, then addCapability for the bonfire
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return  print a statement for notice the player bonfire is lighted
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        actor.addCapability(Status.LIGHTING);
        bonfire.addCapability(Status.ACTIVE_BONFIRE);
        return "________      ____   ___      ___________ ___________   __________       ____     ______________ \n" +
                "`MMMMMMMb.   6MMMMb  `MM\\     `M'`MMMMMMM `MM`MMMMMMMb. `MMMMMMMMM       `MM'     `MM'MMMMMMMMMM \n" +
                " MM    `Mb  8P    Y8  MMM\\     M  MM    \\  MM MM    `Mb  MM      \\        MM       MM /   MM   \\ \n" +
                " MM     MM 6M      Mb M\\MM\\    M  MM       MM MM     MM  MM               MM       MM     MM     \n" +
                " MM    .M9 MM      MM M \\MM\\   M  MM   ,   MM MM     MM  MM    ,          MM       MM     MM     \n" +
                " MMMMMMM(  MM      MM M  \\MM\\  M  MMMMMM   MM MM    .M9  MMMMMMM          MM       MM     MM     \n" +
                " MM    `Mb MM      MM M   \\MM\\ M  MM   `   MM MMMMMMM9'  MM    `          MM       MM     MM     \n" +
                " MM     MM MM      MM M    \\MM\\M  MM       MM MM  \\M\\    MM               MM       MM     MM     \n" +
                " MM     MM YM      M9 M     \\MMM  MM       MM MM   \\M\\   MM               MM       MM     MM     \n" +
                " MM    .M9  8b    d8  M      \\MM  MM       MM MM    \\M\\  MM      /        MM    /  MM     MM     \n" +
                "_MMMMMMM9'   YMMMM9  _M_      \\M _MM_     _MM_MM_    \\M\\_MMMMMMMMM       _MMMMMMM _MM_   _MM_    \n" +
                "                                                                                               ";
    }

    /**
     * show the light action in menu
     * @param actor The actor performing the action.
     * @return  statement that light bonfire
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Light " + bonfire.bonfireName;
    }
}
