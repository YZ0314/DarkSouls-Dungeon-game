package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.interfaces.Consumable;

/**
 *	@author: KAM LUNG YIM
 * 	@author: Trinna De Guzman
 * 	@author: Ivan He
 *
 *	@Version: 1.0.0
 * 	@last updated: 26/09/2021
 */

/**
 * A consume action for consumable items
 */
public class ConsumeAction extends Action {

    private String consumeName;
    Consumable consumable;

    /**
     * constructor for the consumable action
     * @param
     */
    public ConsumeAction(String consumeName, Consumable consumable) {
     this.consumeName = consumeName;
     this.consumable=consumable;
    }

    /**
     * a action that heal the actor if Estus Flask is still enough
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return  statement for whether this action is activate
     */
    @Override
    public String execute(Actor actor, GameMap map) {
      return consumable.consumedBy(actor);
    }

    /**
     * print out action in menu for player to pick
     * @param actor The actor performing the action.
     * @return  show how many charge of Estus Flask for player
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Consume "+ consumeName +consumable.asConsumable().getConsumeName();
    }
}
