package edu.monash.fit2099.demo.mars;

import edu.monash.fit2099.engine.WeaponItem;

public class Stick extends WeaponItem {

	public Stick() {
		super("stick", '/', 10, "pokes",100);
	}

}
